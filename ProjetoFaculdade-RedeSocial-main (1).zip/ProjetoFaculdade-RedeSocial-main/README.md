# :convenience_store: UNIKUT Rede Social

  <p align="center">
    <img src = https://postimg.cc/0bQPGtsR/>
  </p>

Projeto UNIKUT Programação 3

## :gear: Requerimentos

- [JDK 18.x.x.](https://www.oracle.com/java/technologies/downloads/);

### Install:

1. Clone o repositório `https://github.com/diegodanielsantana00/ProjetoFaculdade-RedeSocial.git`

2. Entre na pasta criada `cd ProjetoFaculdade-RedeSocial`

3. Inicie `Main.java` para inicar o Projeto.
